/* function prototype from parse.c */

#ifndef PARSE_H
#define PARSE_H

A_exp parse(string fname);

#endif
